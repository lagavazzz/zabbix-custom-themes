#!/bin/sh
# Installs the Halloween theme into an existing Zabbix frontend.
#
# Usage:  sudo sh install.sh [frontend_dir]
#         sudo sh install.sh --uninstall [frontend_dir]
#
# frontend_dir is the folder that contains zabbix.php
# (usually /usr/share/zabbix or /usr/share/zabbix/ui).

set -e

HERE=$(cd "$(dirname "$0")" && pwd)
MODE=install
if [ "$1" = "--uninstall" ]; then MODE=uninstall; shift; fi

DIR="$1"
if [ -z "$DIR" ]; then
	for d in /usr/share/zabbix/ui /usr/share/zabbix /var/www/html/zabbix /var/www/zabbix; do
		if [ -f "$d/zabbix.php" ]; then DIR="$d"; break; fi
	done
fi

if [ -z "$DIR" ] || [ ! -f "$DIR/zabbix.php" ]; then
	echo "Zabbix frontend not found. Pass the folder that contains zabbix.php, e.g.:"
	echo "  sudo sh install.sh /usr/share/zabbix"
	exit 1
fi

APP="$DIR/include/classes/core/APP.php"
CSS="$DIR/assets/styles/halloween-theme.css"

if [ "$MODE" = "uninstall" ]; then
	rm -f "$CSS"
	if [ -f "$APP.before-halloween" ]; then
		mv "$APP.before-halloween" "$APP"
		echo "Restored the original APP.php."
	fi
	echo "Halloween theme removed. Users who had it selected fall back to the default theme."
	exit 0
fi

VERSION=$(sed -n "s/.*define('ZABBIX_VERSION',[[:space:]]*'\([0-9]*\.[0-9]*\).*/\1/p" "$DIR/include/defines.inc.php")
case "$VERSION" in
	6.0|6.2|6.4) PKG=6.0 ;;
	7.0|7.2)     PKG=7.0 ;;
	7.4)         PKG=7.4 ;;
	8.*)         PKG=8.0 ;;
	*) echo "Unsupported Zabbix frontend version: '$VERSION' (supported: 6.0, 7.0, 7.4, 8.0)."; exit 1 ;;
esac
echo "Found Zabbix $VERSION frontend in $DIR, installing the $PKG build."

cp "$HERE/$PKG/assets/styles/halloween-theme.css" "$CSS"
chmod 644 "$CSS"

if grep -q "halloween-theme" "$APP"; then
	echo "APP.php already registers the Halloween theme; leaving it as is."
elif grep -q "static function" "$APP"; then
	echo "Your APP.php is already customised, so it was NOT replaced."
	echo "Add the methods from $HERE/$PKG/include/classes/core/APP.php to it by hand."
else
	cp "$APP" "$APP.before-halloween"
	cp "$HERE/$PKG/include/classes/core/APP.php" "$APP"
	chmod 644 "$APP"
	echo "APP.php updated (backup: APP.php.before-halloween)."
fi

echo "Done. Select it in User settings > Profile > Theme, or set it as the default in Administration > General > GUI."
