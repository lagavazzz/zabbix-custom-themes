# Zabbix Halloween theme

A dark theme with pumpkins, spider webs, a dangling spider and a bat on the sign-in page.
It is a drop-in add-on for an already installed Zabbix frontend: no rebuild needed.

## Install (automatic)

```sh
unzip zabbix-halloween-theme.zip
cd zabbix-halloween-theme
sudo sh install.sh                      # auto-detects /usr/share/zabbix[/ui]
sudo sh install.sh /path/to/frontend    # or pass the folder that contains zabbix.php
```

The script finds your Zabbix version, copies the matching stylesheet and registers the theme.
It backs up `APP.php` as `APP.php.before-halloween`, and leaves the file alone if you already customised it.

To remove: `sudo sh install.sh --uninstall`

## Install (manual copy)

Pick the folder for your version (`6.0`, `7.0`, `7.4` or `8.0`) and copy its contents into
the frontend folder, which is the one that contains `zabbix.php`:

```sh
sudo cp -r 7.0/* /usr/share/zabbix/
```

This places two files:

| File | Purpose |
|---|---|
| `assets/styles/halloween-theme.css` | the theme stylesheet |
| `include/classes/core/APP.php` | adds "Halloween" to the theme list (replaces the stock, empty `APP.php`) |

If your `APP.php` already has custom code, copy the `getThemes()` (and `getColorScheme()`) methods into it instead of overwriting it.

## Use it

* For yourself: **User settings → Profile → Theme → Halloween**
* For everyone: **Administration → General → GUI → Default theme → Halloween**

## Notes

* Builds were generated from Zabbix 6.0.49, 7.0.32, 7.4.16 and current master (8.0) sources.
  6.2/6.4 use the 6.0 build, and 7.2 uses the 7.0 build.
* A Zabbix package upgrade replaces `APP.php`, so run `install.sh` again after upgrading.
* Decorations can't be clicked and don't block anything. Animations stop when the OS "reduce motion" setting is on.
